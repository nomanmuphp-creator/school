package com.coresyncs.scholentra

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
